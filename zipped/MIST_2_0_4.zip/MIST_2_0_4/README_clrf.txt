See readme.html (Firefox only).
