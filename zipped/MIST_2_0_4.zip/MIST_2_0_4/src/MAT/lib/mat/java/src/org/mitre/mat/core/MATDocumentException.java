/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.mitre.mat.core;

/**
 *
 * @author sam
 */
public class MATDocumentException extends java.lang.Exception {

    public MATDocumentException(String string) {
        super(string);
    }

}
