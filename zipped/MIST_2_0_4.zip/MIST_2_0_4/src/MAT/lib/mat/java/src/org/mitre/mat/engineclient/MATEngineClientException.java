/*
 * Copyright (C) 2009 The MITRE Corporation. See the toplevel
 * file LICENSE for license terms.
 */

package org.mitre.mat.engineclient;

/**
 *
 * @author sam
 */
public class MATEngineClientException extends java.lang.Exception {

    public MATEngineClientException(String message) {
        super(message);
    }

}
