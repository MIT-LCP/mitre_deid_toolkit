/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.mitre.mat.core;

/**
 *
 * @author ROBYN
 */
public class AnnotationException extends java.lang.Exception {

    public AnnotationException(String string) {
        super(string);
    }
    
}
