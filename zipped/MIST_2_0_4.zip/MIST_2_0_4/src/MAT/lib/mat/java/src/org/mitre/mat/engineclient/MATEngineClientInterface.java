/*
 * Copyright (C) 2009 The MITRE Corporation. See the toplevel
 * file LICENSE for license terms.
 */

package org.mitre.mat.engineclient;

/**
 * What will someday be an API for arbitrary MAT clients, independent
 * of protocol.
 *
 * @author sam
 */
public interface MATEngineClientInterface {

}
