"""Regression test suite for CherryPy.

Run test.py to exercise all tests.
"""

